﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VendingMachineTutorial.Models
{
    public class VendingBank
    {
        public double Payments { get; set; }
        public double Pending { get; set; }
    }
}
